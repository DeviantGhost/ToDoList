//
//  ViewController.swift
//  Pratice
//
//  Created by Carlon Rosales on 7/23/21.
//

import UIKit

class ViewController: UIViewController {
    
    let array = [1, 2, 3, 3, 4, 5, 5, 5]
    var repeatArray : [Int] = []
    var numFrequency = [Int: Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for num in array {
            
            if numFrequency[num] != nil {
                numFrequency[num]? += 1
            }else{
                numFrequency[num] = 1
            }
        }
        
        for (k,v) in numFrequency {
            if v > 1 {
                repeatArray.append(k)
            }
        }
        print(repeatArray)
        
    }
}

